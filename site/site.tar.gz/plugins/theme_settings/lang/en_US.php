<?php
$i18n = array(
    'RESET' => "Reset",
    'SAVE' => "Save Settings",
    'SETTINGS_TITLE' => "Theme Settings",
    'SETTINGS_VIEW' => "Configure Theme"
);