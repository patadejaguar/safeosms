<?php
/**
 * cron.php removed in version 3.1
 */
?>