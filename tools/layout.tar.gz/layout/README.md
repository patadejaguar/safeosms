layoutit
========

基于 bootstrap 实现可视化布局的 layoutit.com 离线中文版

## 新增功能

- html5 自动保存
- 开启元素立即编辑模式
- 增加撤销
- 重做跟踪操作功能
- 加入 ckeditor 弹出编辑器

原版程序地址: <a href="http://layoutit.com" target="_blank">layoutit.com</a>
